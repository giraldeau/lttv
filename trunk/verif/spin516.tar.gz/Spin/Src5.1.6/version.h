#define SpinVersion	"Spin Version 5.1.6 -- 9 May 2008"
